let suma = require('../src/sum');

describe("Pruebas del archivo sum.js", () => {

    beforeAll(() => {
        // se ejecuta una sola vez, antes de la primera prueba
        // Abrir el fichero o logs donde guardar resultados
        // Inicializar algun recurso
        console.log("Empezamos a testear sum.js");
    });

    afterAll(() => {
        // se ejecuta una sola vez, al final de la ultima prueba
        // Cerrar o liberar recursos
         console.log("Terminado de testear sum.js");
    });

    beforeEach(() => {
        // se ejecuta varias veces, antes de cada prueba
        console.log("Ejecutando el test .........")
    });

    afterEach(() => {
        // se ejecuta varias veces,despues de cada prueba
        console.log("Finalizado el test .........")
    });

    // test(titulo, prueba)
    it("Probar la funcion suma", () => {
        // espero que al sumar 5 y 3 la funcion suma retorne 8
        expect(suma(5,3)).toBe(8); 
    }); 

    it("Probar la igualdad de parametros", () => {
        expect({a:5, b:3}).toEqual({a:5, b:3});
    }); 

    it("Probar true", () => {
        expect(suma(5,3) > 0).toBeTruthy();
    });

    it("Probar false", () => {
        expect(suma(5,3) < 0).toBeFalsy();
    });

});