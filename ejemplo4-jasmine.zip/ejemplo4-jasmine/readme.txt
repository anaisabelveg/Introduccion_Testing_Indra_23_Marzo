1.- Descargar Visual Studio code https://code.visualstudio.com/download
2.- Instalar node https://nodejs.org/es/download
3.- Crear el proyecto ejemplo4-jasmine
4.- Crear la carpeta src 
5.- Crear sum.js en src 
6.- convertir en un proyecto node:  npm init -y    con esto genera package.json 
7.- agregar el framework jest:   npm install --save-dev jasmine
8.- en el package.json modifico "test": "jasmine"
9.- crear la carpeta spec:   npx jasmine init
9.- crear la prueba unitaria en la carpeta spec IMPORTANTE!!  xxxSpec.js
10.- ejecutar la prueba:  npx jasmine