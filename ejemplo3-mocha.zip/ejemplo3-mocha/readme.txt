1.- Descargar Visual Studio code https://code.visualstudio.com/download
2.- Instalar node https://nodejs.org/es/download
3.- Crear el proyecto ejemplo3-mocha
4.- Crear la carpeta src 
5.- Crear sum.js en src 
6.- convertir en un proyecto node:  npm init -y    con esto genera package.json 
7.- agregar el framework jest:   npm install --save-dev mocha chai
8.- en el package.json modifico "test": "mocha"
9.- crear la prueba unitaria en la carpeta test
10.- ejecutar la prueba:  npx mocha