package es.indra.models;

public class Producto {

}
