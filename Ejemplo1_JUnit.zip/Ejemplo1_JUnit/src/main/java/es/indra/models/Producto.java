package es.indra.models;

import java.util.Objects;

public class Producto {

	private int ID;
	private String descripcion;
	private double precio;

	public Producto() {
		// TODO Auto-generated constructor stub
	}

	public Producto(int iD, String descripcion, double precio) {
		super();
		ID = iD;
		this.descripcion = descripcion;
		this.precio = precio;
	}

	public int getID() {
		return ID;
	}

	public void setID(int iD) {
		ID = iD;
	}

	public String getDescripcion() {
		return descripcion;
	}

	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}

	public double getPrecio() {
		return precio;
	}

	public void setPrecio(double precio) {
		if (precio <= 0) {
			throw new RuntimeException("El precio debe ser positivo");
		}
		this.precio = precio;
	}

	@Override
	public int hashCode() {
		return Objects.hash(ID, descripcion, precio);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Producto other = (Producto) obj;
		return ID == other.ID && Objects.equals(descripcion, other.descripcion)
				&& Double.doubleToLongBits(precio) == Double.doubleToLongBits(other.precio);
	}
	
} // cierra la clase










