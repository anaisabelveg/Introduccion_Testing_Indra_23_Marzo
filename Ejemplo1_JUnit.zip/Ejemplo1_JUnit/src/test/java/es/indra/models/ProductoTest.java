package es.indra.models;

import org.junit.jupiter.api.Test;

public class ProductoTest {
	
	@Test
	void testDescripcion() {
		Producto producto = new Producto();
		String descripcionReal = "Impresora";
		String descripcionEsperada = producto.get
	}

}
