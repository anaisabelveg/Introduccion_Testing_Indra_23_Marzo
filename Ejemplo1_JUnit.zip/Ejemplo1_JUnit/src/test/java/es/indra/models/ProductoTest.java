package es.indra.models;

import java.util.Arrays;
import java.util.List;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.condition.DisabledOnOs;
import org.junit.jupiter.api.condition.EnabledOnJre;
import org.junit.jupiter.api.condition.EnabledOnOs;
import org.junit.jupiter.api.condition.JRE;
import org.junit.jupiter.api.condition.OS;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvFileSource;
import org.junit.jupiter.params.provider.CsvSource;
import org.junit.jupiter.params.provider.MethodSource;
import org.junit.jupiter.params.provider.ValueSource;

public class ProductoTest {

	Producto producto;

	@BeforeAll
	static void inicioClasePrueba() {
		System.out.println("Empezamos a probar la clase ProductoTest");
	}

	@AfterAll
	static void finClasePrueba() {
		System.out.println("Terminamos de probar la clase ProductoTest");
	}

	@BeforeEach
	void inicioTest() {
		producto = new Producto(1, "Impresora", 129.95);
	}

	@AfterEach
	void finTest() {
		System.out.println("Prueba finalizada");
	}

	@Nested
	@DisplayName("Test de la clase Producto")
	class ProductoPruebas {

		@Test
		void testDescripcion() {
			// Producto producto = new Producto(1, "Impresora", 129.95);
			String descripcionEsperada = "Impresora";
			String descripcionReal = producto.getDescripcion();
			Assertions.assertEquals(descripcionEsperada, descripcionReal);
		}

		@Test
		void testPrecio() {
			// Producto producto = new Producto(1, "Impresora", 129.95);
			// Assertions.assertTrue(producto.getPrecio() > 0);
			Assertions.assertFalse(producto.getPrecio() < 0);
		}

		@Test
		void testIgualdadProductos() {
			Producto producto2 = new Producto(1, "Impresora", 129.95);
			Assertions.assertEquals(producto, producto2);
		}

		@Test
		void testPrecioNegativoException() {
			Exception exception = Assertions.assertThrows(Exception.class, () -> {
				producto.setPrecio(-20);
			});

			String msgReal = exception.getMessage();
			String msgEsperado = "El precio debe ser positivo";
			Assertions.assertEquals(msgEsperado, msgReal);
		}

	}
	
	@Nested
	@DisplayName("Habilitar o deshabilitar pruebas segun SO o el JRE")
	class SO_JRE{
		
		@Test
		@EnabledOnOs(OS.WINDOWS)
		void testWindows() {
			System.out.println("Tu SO es Windows");
		}
		
		@Test
		@DisabledOnOs(OS.WINDOWS)
		void testNotWindows() {
			System.out.println("Tu SO NO es Windows");
		}
		
		@Test
		@EnabledOnJre(JRE.JAVA_26)
		void testJava26() {
			System.out.println("Tu version de Java es la 26");
		}
		
		@Test
		@EnabledOnJre(JRE.JAVA_8)
		void testJava8() {
			System.out.println("Tu version de Java es la 8");
		}
		
		// Tambien existe @DisabledOnJRE
		
	}
	
	// Test parametrizados: se trata de pasar varios datos como parametros
	// y asi realizar la prueba con cada uno de ellos
	@ParameterizedTest(name = "parametro {index} con valor {0}")
	@ValueSource(doubles = {129.95, -35, 275, 0}) // doubles porque el precio es de tipo double
	void testPrecio(double precio) {
		producto.setPrecio(precio);
		Assertions.assertTrue(producto.getPrecio() > 0);
	}
	
	@ParameterizedTest(name = "parametro {index} con valor {0}")
	@CsvSource({"0,129.95", "1,-35", "2,275", "3,0"}) 
	void testPrecioCsvSource(String indice, String precio) {
		producto.setPrecio(Double.parseDouble(precio));
		Assertions.assertTrue(producto.getPrecio() > 0);
	}
	
	@ParameterizedTest(name = "parametro {index} con valor {0}")
	@CsvFileSource(resources = "/datos.csv") 
	void testPrecioCsvFileSource(String precio) {
		producto.setPrecio(Double.parseDouble(precio));
		Assertions.assertTrue(producto.getPrecio() > 0);
	}
	
	@ParameterizedTest(name = "parametro {index} con valor {0}")
	@MethodSource("queryPrecios") 
	void testPrecioMethodSource(Double precio) {
		producto.setPrecio(precio);
		Assertions.assertTrue(producto.getPrecio() > 0);
	}
	
	static List<Double> queryPrecios(){
		// Simulamos que lanzamos una query a la BBDD para traer la lista de precio
		// Tambien podemos lanzar una peticion a un API REST
		return Arrays.asList(129.95, -35.0, 275.0, 0.0);
	}
	

}





