package es.indra.business;

import java.util.Optional;

import es.indra.models.Pelicula;
import es.indra.persistence.IPeliculasDAO;

public class PeliculasBS implements IPeliculasBS {

	private IPeliculasDAO dao;

	public PeliculasBS(IPeliculasDAO dao) {
		super();
		this.dao = dao;
	}

	@Override
	public Pelicula findPeliculaByNombre(String nombre) {
		Optional<Pelicula> peliculaOp = dao.findAll()
				.stream()
				.filter(peli -> peli.getNombre().contains(nombre))
				.findFirst();
		
		Pelicula pelicula = null;
		if (peliculaOp.isPresent())
			pelicula = peliculaOp.get();
		
		return pelicula;
	}

	@Override
	public Pelicula findPeliculaById(Long id) {
		return dao.findPeliculaById(id);
	}

}
