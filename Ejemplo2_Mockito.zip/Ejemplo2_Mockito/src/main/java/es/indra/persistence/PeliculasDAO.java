package es.indra.persistence;

import java.util.Arrays;
import java.util.List;

import es.indra.models.Pelicula;

public class PeliculasDAO implements IPeliculasDAO{

	@Override
	public List<Pelicula> findAll() {
		return Arrays.asList(
				new Pelicula(1L, "El 47"),
				new Pelicula(2L, "La Infiltrada"),
				new Pelicula(3L, "Harry Potter")
		);
	}

}
