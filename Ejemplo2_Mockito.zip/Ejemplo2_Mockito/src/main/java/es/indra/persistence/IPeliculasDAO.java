package es.indra.persistence;

import java.util.List;

import es.indra.models.Pelicula;

public interface IPeliculasDAO {
	
	List<Pelicula> findAll();

}
