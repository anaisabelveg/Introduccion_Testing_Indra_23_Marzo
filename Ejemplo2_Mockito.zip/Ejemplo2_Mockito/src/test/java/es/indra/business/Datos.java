package es.indra.business;

import java.util.Arrays;
import java.util.List;

import es.indra.models.Pelicula;

public class Datos {
	
	public static List<Pelicula> PELICULAS =  Arrays.asList(
			new Pelicula(1L, "Superman"),
			new Pelicula(2L, "Lo que el viento se llevo"),
			new Pelicula(3L, "Torrente Presidente")
	);
	
	public static Pelicula PELICULA = new Pelicula(4L, "Los Vengadores");

}
