package es.indra.business;

import static org.mockito.ArgumentMatchers.anyLong;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;

import es.indra.models.Pelicula;
import es.indra.persistence.IPeliculasDAO;
import es.indra.persistence.PeliculasDAO;

@ExtendWith(MockitoExtension.class)
public class PeliculasBSTest {
	
	@Mock
	// Para poder llamar a metodos reales necesitamos tener la clase y no una interface
	PeliculasDAO dao;
	
	@InjectMocks
	// No podemos inyectar un mock en una interface, es necesario utilizar la clase
	PeliculasBS bs;
	
	@Captor
	ArgumentCaptor<Long> captor;
	
	
	@BeforeEach
	void inicioPrueba() {
		//dao = Mockito.mock(IPeliculasDAO.class);
		//bs = new PeliculasBS(dao);
		
		// Al usar anotaciones necesitamos activarlas:
		// tenemos 2 formas de hacerlo: programatica o con la anotacion @ExtendWith
		//MockitoAnnotations.openMocks(this);
	}
	
	
	@Test
	void testFindPeliculaByNombre() {
		// Crear un objeto Mock (objeto ficticio)
		// No se puede crear un mock de cualquier metodo, solo publicos o default
		// nunca de un metodo privado o estatico y tampoco final
		//IPeliculasDAO dao = Mockito.mock(IPeliculasDAO.class);
		
		// Objeto real
		//IPeliculasBS bs = new PeliculasBS(dao);
		
		// Cuando se llame al metodo findAll del dao que cargue unas peliculas
		Mockito.when(dao.findAll()).thenReturn(Datos.PELICULAS);
		
		Pelicula pelicula = bs.findPeliculaByNombre("Torrente");
		
		Assertions.assertNotNull(pelicula);
		Assertions.assertEquals(3L, pelicula.getId());
		Assertions.assertEquals("Torrente Presidente", pelicula.getNombre());
	}
	
	
	@Test
	void testCapturarArgumentos() {
		Mockito.when(dao.findPeliculaById(4L)).thenReturn(Datos.PELICULA);	
		Pelicula pelicula = bs.findPeliculaById(4L);
		
		// Tenemos que capturar los argumentos
		Mockito.verify(dao).findPeliculaById(captor.capture());
		
		Assertions.assertEquals(4L, captor.getValue());
	}
	
	// Spy es un hibrido entre los mock y los objetos reales
	// Spy no funciona con interfaces o clases abstractas, ha de ser la clase implementada 
	@Test
	void testSpy() {
		PeliculasDAO peliculasDAO = Mockito.spy(PeliculasDAO.class);
		PeliculasBS bs = new PeliculasBS(peliculasDAO);
		
		// Llamar al metodo real
		//Mockito.when(peliculasDAO.findPeliculaById(Mockito.anyLong())).thenReturn(Datos.PELICULA);
		
		// Llamar al mock
		Mockito.doReturn(Datos.PELICULA).when(peliculasDAO).findPeliculaById(Mockito.anyLong());
		
		Pelicula pelicula =  bs.findPeliculaById(5L);
		
		Assertions.assertNotNull(pelicula);
		Assertions.assertEquals(4L, pelicula.getId());
		Assertions.assertEquals("Los Vengadores", pelicula.getNombre());
		
	} 
	
	@Test
	void testCallRealMethod() {
		// Se llamara al metodo real findPeliculaById() del dao
		Mockito.doCallRealMethod().when(dao).findPeliculaById(Mockito.anyLong());
		
		Pelicula pelicula = bs.findPeliculaById(8L);
		Assertions.assertEquals(8L, pelicula.getId());
		Assertions.assertEquals("Spiderman", pelicula.getNombre());
	}
	
	

}





