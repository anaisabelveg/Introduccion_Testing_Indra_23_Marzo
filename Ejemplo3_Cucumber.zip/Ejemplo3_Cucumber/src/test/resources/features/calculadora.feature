Feature: Funcionalidades de la calculadora

	Background:
		Given Iniciamos la calculadora
		
	Scenario Outline: Operaciones básicas
		When el usuario ingresa <numero1> y <numero2>
		And realiza la operacion <operacion>
		Then el resultado debe ser <resultado>
		
	Examples:
		|	numero1	|	numero2	|	operacion	|	resultado	|
		|	4		|	2		|	suma		|	6			|
		|	10		|	3		|	resta		|	7			|
		|	9		|	4		|	multiplicar	|	36			|
		|	8		|	2		|	dividir		|	4			|
		
	Scenario: División por cero
		When el usuario ingresa 4 y 0
		And realiza la operacion dividir
		Then debe mostrar un error "No se puede dividir por cero"